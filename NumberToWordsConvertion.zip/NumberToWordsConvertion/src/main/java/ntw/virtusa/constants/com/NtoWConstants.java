package ntw.virtusa.constants.com;

public class NtoWConstants {
private static final String UNIT_ARRAY[]= {"Zero","One","two","three","four","sive","six","seven","eight","nine","eleven","twel","thirteen","fourteen","fifteen","sixteen","seventeen","eighteen","ninteen"};
	
	
private static final String TENS_ARRAYA[]={"Zero","ten","twenty","thrity","fourty","fifty","sixety","seventy","eighty","ninty"};
	
}
