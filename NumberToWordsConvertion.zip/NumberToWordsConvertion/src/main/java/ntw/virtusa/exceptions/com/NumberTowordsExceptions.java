package ntw.virtusa.exceptions.com;

public class NumberTowordsExceptions extends Exception {
	 String messagae;	
	 NumberTowordsExceptions(String msg)
		{
		this.messagae=msg;
		}
	 
public static void main(String[] args) {

System.out.println("Sample Exception class");

	
	
	}
}

